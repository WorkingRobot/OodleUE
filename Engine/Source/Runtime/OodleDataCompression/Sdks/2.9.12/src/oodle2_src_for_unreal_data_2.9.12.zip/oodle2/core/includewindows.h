#pragma once

#ifndef WIN32_LEAN_AND_MEAN
#define WIN32_LEAN_AND_MEAN
#endif

#ifdef _MSC_VER
#pragma warning(push)
#pragma warning(disable : 4163) //intrinsic
#endif

#include <windows.h>

#ifdef _MSC_VER
#pragma warning(pop)
#endif

